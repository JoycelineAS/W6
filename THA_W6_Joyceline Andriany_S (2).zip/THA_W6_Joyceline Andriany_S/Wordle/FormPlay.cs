﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace Wordle
{
    public partial class Form_Play : Form
    {
        int lives;
        int tries;
        int keyStroke;
        string currentWord = "";
        string choosenWord;
        bool playable;
        public Form_Play(int lives)
        {
            InitializeComponent();
            playable = true;
            this.lives = lives;
            this.tries = 0;
            this.keyStroke = 0;
        }

        
        List<List<Button>> arenaList = new List<List<Button>>();
        private void Form_Play_Load(object sender, EventArgs e)
        {
            // CREATE ARENA
            int btnSize = 65;
            int oriPosX = 15;
            int oriPosY = 15;
            int posY = oriPosY;
            for (int row = 0; row < lives; row++)
            {
                int posX = oriPosX;
                arenaList.Add(new List<Button>());
                for (int col = 0; col < 5; col++)
                {
                    Button btn = new Button();
                    btn.Text = "";
                    btn.Size = new Size(btnSize, btnSize);
                    btn.Location = new Point(posX, posY);
                    posX += 2 + btnSize;
                    this.Controls.Add(btn);
                    arenaList.Last().Add(btn);
                }
                posY += 2 + btnSize;
            }
            // CREATE KEYBOARD
            oriPosX = (btnSize * 6) + (2 * 7);
            oriPosY = 15;
            posY = oriPosY;
            string keyboard = "q,w,e,r,t,y,u,i,o,p|a,s,d,f,g,h,j,k,l|enter,z,x,c,v,b,n,m,delete";
            string[] rows = keyboard.Split('|');
            for (int i = 0; i < rows.Count(); i++)
            {
                int posX = oriPosX;
                if (i%2 != 0) posX = oriPosX + 35;
                
                string row = rows[i];
                string[] keys = row.Split(',');
                for (int j = 0; j < keys.Count(); j++)
                {
                    string key = keys[j];

                    Button btn = new Button();
                    btn.Text = key.ToUpper();
                    if (key.Equals("delete") || key.Equals("enter"))
                    {
                        btn.Size = new Size(btnSize + 20, btnSize);
                        btn.Location = new Point(posX, posY);
                        posX += 2 + btnSize + 20;
                        btn.Text = (key[0] + "").ToUpper() + key.Substring(1);
                    } else
                    {
                        btn.Size = new Size(btnSize, btnSize);
                        btn.Location = new Point(posX, posY);
                        posX += 2 + btnSize;
                    }
                    this.Controls.Add(btn);
                    btn.Click += (senderObj, eventArgs) => keyboardClick(btn, key);
                }
                posY += 2 + btnSize;
            }

            // LOAD DATA
            const string f = "WordleWordList.txt";

            string[] lines = File.ReadAllLines(f);
            foreach (string line in lines)
            {
                wordleData.AddRange(line.Split(','));
            }
            choosenWord = wordleData[new Random().Next(wordleData.Count() - 1)];
            MessageBox.Show("Choosen Word: " + choosenWord);
        }
        private void keyboardClick(Button btn, string text) {
            if (!playable) return;
            if (text.Equals("delete"))
            {
                hitDelete();
                return;
            }
            if (text.Equals("enter"))
            {
                hitEnter();
                return;
            }
            hitKey(text);
        }
        private void hitEnter()
        {
            if (currentWord.Length < 5) return;

            if (choosenWord.Equals(currentWord))
            {
                foreach (Button btn in arenaList[tries])
                {
                    btn.BackColor = Color.DarkGreen;
                    btn.ForeColor = Color.White;
                }
                MessageBox.Show("WIN!");
                playable = false;

                return;
            }
            if (!wordleData.Contains(currentWord)) {
                MessageBox.Show("Word not exist!");
                return;
            }
            for (int i = 0; i < choosenWord.Length; i++)
            {
                if (currentWord[i] == choosenWord[i])
                {
                    arenaList[tries][i].BackColor = Color.DarkGreen;
                    arenaList[tries][i].ForeColor = Color.White;
                }
                else if (choosenWord.Contains(currentWord[i]))
                {
                    arenaList[tries][i].BackColor = Color.Yellow;
                }
            }
            tries++;
            currentWord = "";
            if (lives <= tries)
            {
                playable = false;
                MessageBox.Show("GAME OVER");
            }
        }
        private void hitDelete()
        {
            if (currentWord.Equals("")) return;
            arenaList[tries][currentWord.Length-1].Text = "";
            currentWord = currentWord.Substring(0,currentWord.Length-1);
        }
        private void hitKey(string text)
        {
            if (currentWord.Length == 5) return;
            arenaList[tries][currentWord.Length].Text = text.ToUpper();
            currentWord += text;
        }

        private List<string> wordleData = new List<string>();
    }
}
